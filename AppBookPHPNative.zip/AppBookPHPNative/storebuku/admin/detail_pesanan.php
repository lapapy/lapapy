<?php
session_start();
include "../config.php";
$id_pesanan = (int)$_GET['id'];

// Get order data
$query_pesanan = mysqli_query($conn, "
    SELECT pesanan.*, user.username 
    FROM pesanan 
    JOIN user ON pesanan.id_user = user.id_user
    WHERE pesanan.id_pesanan = $id_pesanan
");
$pesanan = mysqli_fetch_assoc($query_pesanan);

// Get order items
$query_items = mysqli_query($conn, "
    SELECT detail_pesanan.*, produk.nama_produk, produk.gambar
    FROM detail_pesanan
    JOIN produk ON detail_pesanan.id_produk = produk.id_produk
    WHERE detail_pesanan.id_pesanan = $id_pesanan
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details #<?= $id_pesanan ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-light: #eef2ff;
            --secondary: #4338ca;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f9fafb;
            --dark: #1f2937;
            --gray: #6b7280;
            --border-radius: 0.5rem;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: #f3f4f6;
            color: var(--dark);
            line-height: 1.6;
            padding: 2rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .order-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .order-header {
            background: var(--primary);
            color: white;
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .order-title {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .order-id {
            font-size: 1rem;
            opacity: 0.9;
        }

        .order-body {
            padding: 2rem;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .section-title i {
            font-size: 1.1rem;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .info-card {
            background: var(--light);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            border-left: 4px solid var(--primary);
        }

        .info-row {
            margin-bottom: 0.75rem;
            display: flex;
        }

        .info-label {
            font-weight: 500;
            color: var(--gray);
            min-width: 120px;
        }

        .info-value {
            font-weight: 500;
        }

        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        .status-pending {
            background-color: #fffbeb;
            color: #d97706;
        }

        .status-verified {
            background-color: #ecfdf5;
            color: #059669;
        }

        .proof-section {
            margin: 2rem 0;
        }

        .proof-container {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-top: 1rem;
        }

        .proof-image {
            width: 300px;
            height: 180px;
            object-fit: contain;
            border-radius: var(--border-radius);
            border: 1px solid #e5e7eb;
            background: white;
            padding: 0.5rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--secondary);
            transform: translateY(-1px);
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin: 2rem 0;
        }

        .items-table thead {
            background: var(--primary);
            color: white;
        }

        .items-table th {
            padding: 1rem;
            text-align: left;
            font-weight: 500;
        }

        .items-table td {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }

        .items-table tr:hover {
            background: var(--primary-light);
        }

        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 0.25rem;
            border: 1px solid #e5e7eb;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary);
            text-decoration: none;
            margin-top: 2rem;
            font-weight: 500;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .proof-container {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .proof-image {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="order-card">
            <div class="order-header">
                <h1 class="order-title">Order Details</h1>
                <div class="order-id">#<?= $id_pesanan ?></div>
            </div>

            <div class="order-body">
                <!-- Order Information -->
                <div class="info-grid">
                    <div class="info-card">
                        <h3 class="section-title"><i class="fas fa-user"></i> Customer Information</h3>
                        <div class="info-row">
                            <span class="info-label">Customer:</span>
                            <span class="info-value"><?= $pesanan['username'] ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Order Date:</span>
                            <span class="info-value"><?= date('d/m/Y H:i', strtotime($pesanan['created_at'])) ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3 class="section-title"><i class="fas fa-truck"></i> Shipping</h3>
                        <div class="info-row">
                            <span class="info-label">Address:</span>
                            <span class="info-value"><?= nl2br($pesanan['alamat']) ?></span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3 class="section-title"><i class="fas fa-credit-card"></i> Payment</h3>
                        <div class="info-row">
                            <span class="info-label">Status:</span>
                            <span class="status-badge <?= ($pesanan['status'] == 'menunggu_verifikasi') ? 'status-pending' : 'status-verified' ?>">
                                <?= ucfirst(str_replace('_', ' ', $pesanan['status'])) ?>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Total:</span>
                            <span class="info-value">Rp <?= number_format($pesanan['total'], 0, ',', '.') ?></span>
                        </div>
                    </div>
                </div>

                <!-- Payment Proof -->
                <div class="proof-section">
                    <h3 class="section-title"><i class="fas fa-receipt"></i> Payment Proof</h3>
                    <?php if ($pesanan['bukti_transfer']): ?>
                        <div class="proof-container">
                            <img src="../bukti_transfer/<?= $pesanan['bukti_transfer'] ?>" alt="Payment Proof" class="proof-image">
                            <a href="../bukti_transfer/<?= $pesanan['bukti_transfer'] ?>" download class="btn btn-primary">
                                <i class="fas fa-download"></i> Download Proof
                            </a>
                        </div>
                    <?php else: ?>
                        <p>No payment proof uploaded yet.</p>
                    <?php endif; ?>
                </div>

                <!-- Order Items -->
                <h3 class="section-title"><i class="fas fa-shopping-basket"></i> Order Items</h3>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Image</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($item = mysqli_fetch_assoc($query_items)): ?>
                            <tr>
                                <td><?= $item['nama_produk'] ?></td>
                                <td><img src="uploads/<?= $item['gambar'] ?>" class="product-image"></td>
                                <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                <td><?= $item['jumlah'] ?></td>
                                <td>Rp <?= number_format($item['harga'] * $item['jumlah'], 0, ',', '.') ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <a href="index.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>