<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin</title>
    <style>
        /* Compiled CSS from SCSS */
        :root {
            --dark-bg: #0f0e17;
            --card-bg: #16161a;
            --text-primary: #fffffe;
            --text-secondary: #94a1b2;
            --accent: #7f5af0;
            --neon: #2cb67d;
            --error: #ef4565;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--dark-bg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: var(--text-primary);
            background-image: 
                radial-gradient(circle at 25% 25%, rgba(47, 47, 97, 0.8) 0%, transparent 50%),
                radial-gradient(circle at 75% 75%, rgba(127, 90, 240, 0.5) 0%, transparent 50%);
        }

        .register-card {
            background-color: var(--card-bg);
            border-radius: 16px;
            padding: 2.5rem;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.05);
            position: relative;
            overflow: hidden;
        }

        .register-card::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, var(--accent), var(--neon));
            z-index: -1;
            filter: blur(5px);
            opacity: 0.7;
        }

        .register-header {
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }

        .register-header h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--accent), var(--neon));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: inline-block;
        }

        .register-header p {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 0.8rem 1rem;
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--neon);
            box-shadow: 0 0 0 2px rgba(44, 182, 125, 0.2);
            background-color: rgba(44, 182, 125, 0.05);
        }

        .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.3);
        }

        .btn-register {
            width: 100%;
            padding: 0.8rem;
            background: linear-gradient(45deg, var(--accent), var(--neon));
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        .btn-register::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(44, 182, 125, 0.4);
        }

        .btn-register:hover::before {
            left: 100%;
        }

        .btn-register:active {
            transform: translateY(0);
        }

        .register-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .register-footer a {
            color: var(--neon);
            text-decoration: none;
            font-weight: 500;
            position: relative;
        }

        .register-footer a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 1px;
            background-color: var(--neon);
            transition: width 0.3s ease;
        }

        .register-footer a:hover::after {
            width: 100%;
        }

        @media (max-width: 480px) {
            .register-card {
                padding: 1.5rem;
                margin: 0 1rem;
            }
            
            .register-header h2 {
                font-size: 1.5rem;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="register-card">
        <div class="register-header">
            <h2>Create Admin Account</h2>
            <p>Join our administration panel</p>
        </div>

        <form action="proses_register.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required placeholder="Enter your username">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Create a password">
            </div>

            <button type="submit" class="btn-register">Register Now</button>
        </form>

        <div class="register-footer">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</body>
</html>