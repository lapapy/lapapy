<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

// Ambil data keranjang
$query = mysqli_query($conn, "
    SELECT produk.nama_produk, produk.harga, keranjang.jumlah, produk.gambar 
    FROM keranjang 
    JOIN produk ON keranjang.id_produk = produk.id_produk 
    WHERE keranjang.id_user = {$_SESSION['user_id']}
");

$total = 0;
$item_count = mysqli_num_rows($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: #4CAF50;
            --primary-dark: #388E3C;
            --secondary: #607D8B;
            --light: #f5f5f5;
            --dark: #212121;
            --gray: #757575;
            --white: #ffffff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f9f9f9;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: var(--primary);
            color: var(--white);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 24px;
            font-weight: bold;
        }
        
        .nav-links a {
            color: var(--white);
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }
        
        .page-title {
            text-align: center;
            margin: 30px 0;
            color: var(--primary);
            font-size: 28px;
        }
        
        .cart-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }
        
        .cart-items {
            flex: 2;
            background: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 20px;
        }
        
        .cart-summary {
            flex: 1;
            background: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 20px;
            height: fit-content;
        }
        
        .cart-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
            align-items: center;
        }
        
        .cart-item:last-child {
            border-bottom: none;
        }
        
        .item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 20px;
        }
        
        .item-details {
            flex: 1;
        }
        
        .item-name {
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--dark);
        }
        
        .item-price {
            color: var(--primary);
            font-weight: 600;
        }
        
        .item-quantity {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        
        .quantity-btn {
            background: var(--light);
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .quantity-input {
            width: 50px;
            text-align: center;
            margin: 0 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
        }
        
        .remove-btn {
            color: var(--gray);
            background: none;
            border: none;
            cursor: pointer;
            margin-left: 20px;
        }
        
        .summary-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--dark);
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .total-row {
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
            font-weight: 600;
            font-size: 18px;
        }
        
        .checkout-btn {
            background-color: var(--primary);
            color: var(--white);
            border: none;
            padding: 12px 20px;
            width: 100%;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
            transition: background 0.3s;
        }
        
        .checkout-btn:hover {
            background-color: var(--primary-dark);
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px 0;
        }
        
        .empty-cart i {
            font-size: 50px;
            color: var(--gray);
            margin-bottom: 20px;
        }
        
        .empty-cart p {
            margin-bottom: 20px;
            color: var(--gray);
        }
        
        .continue-btn {
            background-color: var(--secondary);
            color: var(--white);
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }
        
        @media (max-width: 768px) {
            .cart-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Toko Online</div>
            <div class="nav-links">
                <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
                <!-- <a href="#"><i class="fas fa-user"></i> Profil</a> -->
            </div>
        </div>
    </header>
    
    <div class="container">
        <h1 class="page-title">Keranjang Belanja Anda</h1>
        
        <div class="cart-container">
            <div class="cart-items">
                <?php if ($item_count == 0): ?>
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Keranjang belanja Anda kosong</p>
                        <a href="index.php" class="continue-btn">Lanjutkan Belanja</a>
                    </div>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($query)): ?>
                        <div class="cart-item">
                            <img src="<?php echo isset($row['gambar']) ? $row['gambar'] : 'placeholder.jpg'; ?>" alt="<?php echo $row['nama_produk']; ?>" class="item-image">
                            <div class="item-details">
                                <div class="item-name"><?php echo $row['nama_produk']; ?></div>
                                <div class="item-price">Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></div>
                                <div class="item-quantity">
                                    <button class="quantity-btn"><i class="fas fa-minus"></i></button>
                                    <input type="text" class="quantity-input" value="<?php echo $row['jumlah']; ?>" readonly>
                                    <button class="quantity-btn"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                            <button class="remove-btn"><i class="fas fa-trash"></i></button>
                        </div>
                        <?php $total += $row['harga'] * $row['jumlah']; ?>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
            
            <?php if ($item_count > 0): ?>
            <div class="cart-summary">
                <h3 class="summary-title">Ringkasan Belanja</h3>
                <div class="summary-row">
                    <span>Total Harga (<?php echo $item_count; ?> item)</span>
                    <span>Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
                </div>
                <div class="summary-row">
                    <span>Ongkos Kirim</span>
                    <span>Rp 0</span>
                </div>
                <div class="summary-row total-row">
                    <span>Total Pembayaran</span>
                    <span>Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
                </div>
                <a href="checkout.php" onclick="return validateCheckout()" class="checkout-btn">Proses Checkout</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function validateCheckout() {
            <?php if ($item_count == 0): ?>
                alert("Keranjang kosong! Tambahkan produk terlebih dahulu.");
                window.location.href = "index.php";
                return false;
            <?php else: ?>
                return true;
            <?php endif; ?>
        }
    </script>
</body>
</html>