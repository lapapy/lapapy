<?php
include "../config.php";
if (!isset($_GET['id'])) {
    echo "ID tidak ditemukan!";
    exit;
}

$id = $_GET['id'];
$query = "SELECT * FROM produk WHERE id_produk = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "Produk tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* SCSS Compiled Styles */
        :root {
          --primary: #4361ee;
          --secondary: #3f37c9;
          --accent: #4895ef;
          --light: #f8f9fa;
          --dark: #212529;
          --text: #333333;
          --text-light: #6c757d;
          --success: #4cc9f0;
          --error: #e63946;
          --border-radius: 8px;
          --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          --transition: all 0.3s ease;
        }
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background-color: #f5f7fa;
          color: var(--text);
          line-height: 1.6;
          padding: 2rem;
        }
        
        .container {
          max-width: 800px;
          margin: 0 auto;
          background: white;
          border-radius: var(--border-radius);
          box-shadow: var(--box-shadow);
          padding: 2rem;
        }
        
        h2 {
          color: var(--primary);
          margin-bottom: 1.5rem;
          text-align: center;
          font-size: 1.8rem;
        }
        
        .form-group {
          margin-bottom: 1.5rem;
        }
        
        label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 500;
          color: var(--text);
        }
        
        input[type="text"],
        input[type="number"],
        select,
        textarea {
          width: 100%;
          padding: 0.8rem 1rem;
          border: 1px solid #e0e0e0;
          border-radius: var(--border-radius);
          font-family: inherit;
          font-size: 1rem;
          transition: var(--transition);
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus,
        select:focus,
        textarea:focus {
          outline: none;
          border-color: var(--accent);
          box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
        }
        
        textarea {
          min-height: 120px;
          resize: vertical;
        }
        
        .current-image {
          margin: 1rem 0;
        }
        
        .current-image img {
          border-radius: var(--border-radius);
          border: 1px solid #e0e0e0;
          max-width: 200px;
          height: auto;
        }
        
        .file-input {
          position: relative;
          margin: 1rem 0;
        }
        
        .file-input input[type="file"] {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          opacity: 0;
          cursor: pointer;
        }
        
        .file-input-label {
          display: inline-block;
          padding: 0.8rem 1.5rem;
          background-color: var(--light);
          color: var(--text);
          border-radius: var(--border-radius);
          border: 1px dashed #b0b0b0;
          transition: var(--transition);
          text-align: center;
          width: 100%;
        }
        
        .file-input-label:hover {
          background-color: #e9ecef;
        }
        
        .file-input-label i {
          margin-right: 0.5rem;
        }
        
        .btn-submit {
          background-color: var(--primary);
          color: white;
          border: none;
          padding: 0.8rem 1.5rem;
          border-radius: var(--border-radius);
          font-size: 1rem;
          font-weight: 500;
          cursor: pointer;
          transition: var(--transition);
          width: 100%;
          margin-top: 1rem;
        }
        
        .btn-submit:hover {
          background-color: var(--secondary);
          transform: translateY(-2px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        @media (max-width: 768px) {
          body {
            padding: 1rem;
          background: white;
          }
          
          .container {
            box-shadow: none;
            padding: 1rem;
          }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2><i class="fas fa-edit"></i> Edit Produk</h2>

        <form action="proses_edit.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_produk" value="<?php echo $data['id_produk']; ?>">
            <input type="hidden" name="gambar_lama" value="<?php echo $data['gambar']; ?>">

            <div class="form-group">
                <label for="nama_produk">Nama Produk</label>
                <input type="text" id="nama_produk" name="nama_produk" value="<?php echo $data['nama_produk']; ?>" required>
            </div>

            <div class="form-group">
                <label for="kategori_produk">Kategori</label>
                <select id="kategori_produk" name="kategori_produk" required>
                    <option value="Elektronik" <?php echo ($data['kategori_produk'] == 'Elektronik') ? 'selected' : ''; ?>>Elektronik</option>
                    <option value="Pakaian" <?php echo ($data['kategori_produk'] == 'Pakaian') ? 'selected' : ''; ?>>Pakaian</option>
                    <option value="Makanan" <?php echo ($data['kategori_produk'] == 'Makanan') ? 'selected' : ''; ?>>Makanan</option>
                    <option value="Aksesoris" <?php echo ($data['kategori_produk'] == 'Aksesoris') ? 'selected' : ''; ?>>Aksesoris</option>
                </select>
            </div>

            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="number" id="harga" name="harga" value="<?php echo $data['harga']; ?>" required>
            </div>

            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" required><?php echo $data['deskripsi']; ?></textarea>
            </div>

            <div class="form-group">
                <label for="stok">Stok</label>
                <input type="number" id="stok" name="stok" value="<?php echo $data['stok']; ?>" required>
            </div>

            <div class="form-group">
                <label>Gambar Saat Ini</label>
                <div class="current-image">
                    <img src="uploads/<?php echo $data['gambar']; ?>" alt="Gambar Produk">
                </div>
            </div>

            <div class="form-group">
                <label>Gambar Baru</label>
                <div class="file-input">
                    <label class="file-input-label" for="gambar">
                        <i class="fas fa-cloud-upload-alt"></i> Pilih File Gambar
                    </label>
                    <input type="file" id="gambar" name="gambar" accept="image/*">
                </div>
            </div>

            <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>