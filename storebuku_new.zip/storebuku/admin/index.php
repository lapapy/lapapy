<?php
session_start();
include "../config.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Process form submission
if (isset($_POST['submit'])) {
    $nama_produk = $_POST['nama_produk'];
    $kategori_produk = $_POST['kategori_produk'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];

    // Upload image
    $gambar = $_FILES['gambar']['name'];
    $tmp_name = $_FILES['gambar']['tmp_name'];
    $upload_dir = "uploads/";

    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $gambar_path = $upload_dir . basename($gambar);

    if (move_uploaded_file($tmp_name, $gambar_path)) {
        $query = "INSERT INTO produk (nama_produk, kategori_produk, gambar, harga, deskripsi, stok) 
                  VALUES ('$nama_produk', '$kategori_produk', '$gambar', '$harga', '$deskripsi', '$stok')";

        if (mysqli_query($conn, $query)) {
            $success_msg = "Produk berhasil ditambahkan!";
        } else {
            $error_msg = "Error: " . mysqli_error($conn);
        }
    } else {
        $error_msg = "Gagal upload gambar.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Compiled SCSS */
        :root {
            --primary: #4361ee;
            --primary-light: #eef2ff;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #94a3b8;
            --border: #e2e8f0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9;
            color: var(--dark);
            line-height: 1.6;
        }

        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            padding: 1.5rem 0;
        }

        .sidebar-header {
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--border);
        }

        .sidebar-header h2 {
            color: var(--primary);
            font-size: 1.25rem;
        }

        .sidebar-menu {
            padding: 1rem 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--dark);
            text-decoration: none;
            transition: all 0.2s;
        }

        .menu-item:hover {
            background-color: var(--primary-light);
            color: var(--primary);
        }

        .menu-item.active {
            background-color: var(--primary-light);
            color: var(--primary);
            border-left: 3px solid var(--primary);
        }

        .menu-item i {
            margin-right: 0.75rem;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            padding: 2rem;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .header h1 {
            font-size: 1.75rem;
            color: var(--dark);
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 0.75rem;
        }

        .logout-btn {
            background-color: var(--danger);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }

        .logout-btn:hover {
            background-color: #e11d48;
        }

        .logout-btn i {
            margin-right: 0.5rem;
        }

        /* Cards */
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border);
        }

        .card-header h2 {
            font-size: 1.25rem;
            color: var(--dark);
        }

        .btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            display: inline-flex;
            align-items: center;
        }

        .btn-primary {
            background-color: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--secondary);
        }

        .btn i {
            margin-right: 0.5rem;
        }

        /* Forms */
        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-family: inherit;
            transition: all 0.2s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        /* Tables */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .table th, .table td {
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        .table th {
            background-color: var(--primary-light);
            color: var(--primary);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
        }

        .table tr:hover {
            background-color: #f8fafc;
        }

        .table img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }

        .badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-pending {
            background-color: #fef3c7;
            color: #92400e;
        }

        .badge-diproses {
            background-color: #dbeafe;
            color: #1e40af;
        }

        .badge-dikirim {
            background-color: #d1fae5;
            color: #065f46;
        }

        .badge-selesai {
            background-color: #ede9fe;
            color: #5b21b6;
        }

        .action-link {
            color: var(--primary);
            text-decoration: none;
            margin-right: 0.75rem;
            transition: all 0.2s;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .action-link.delete {
            color: var(--danger);
        }

        select.status-select {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            border: 1px solid var(--border);
            font-size: 0.875rem;
            cursor: pointer;
        }

        /* Alerts */
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background-color: #fef2f2;
            color: #b91c1c;
            border-left: 4px solid #ef4444;
        }

        .alert i {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .admin-container {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                display: none;
            }
        }

        @media (max-width: 768px) {
            .table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav class="sidebar-menu">
                <a href="index.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </a>
                <a href="#" class="menu-item">
                    <i class="fas fa-box"></i>
                    Produk
                </a>
                <a href="#" class="menu-item">
                    <i class="fas fa-users"></i>
                    Pengguna
                </a>
                <a href="#" class="menu-item">
                    <i class="fas fa-shopping-cart"></i>
                    Pesanan
                </a>
                <a href="#" class="menu-item">
                    <i class="fas fa-chart-bar"></i>
                    Laporan
                </a>
                <a href="#" class="menu-item">
                    <i class="fas fa-cog"></i>
                    Pengaturan
                </a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <h1>Dashboard Admin</h1>
                <div class="user-info">
                    <span>Halo, <?php echo $_SESSION['username'] ?></span>
                    <a href="../logout.php" onclick="return confirm('Yakin ingin logout?');" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </div>

            <!-- Alert Messages -->
            <?php if(isset($success_msg)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>

            <?php if(isset($error_msg)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <!-- Add Product Form -->
            <div class="card">
                <div class="card-header">
                    <h2>Tambah Produk Baru</h2>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" class="form-control" id="nama_produk" name="nama_produk" required>
                    </div>

                    <div class="form-group">
                        <label for="kategori_produk">Kategori Produk</label>
                        <select class="form-control" id="kategori_produk" name="kategori_produk" required>
                            <option value="Sejarah">Sejarah</option>
                            <option value="MaPel">MaPel</option>
                            <option value="Novel">Novel</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="gambar">Gambar Produk</label>
                        <input type="file" class="form-control" id="gambar" name="gambar" required>
                    </div>

                    <div class="form-group">
                        <label for="harga">Harga</label>
                        <input type="number" class="form-control" id="harga" name="harga" required>
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="stok">Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" required>
                    </div>

                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Tambah Produk
                    </button>
                </form>
            </div>

            <!-- Products Table -->
            <div class="card">
                <div class="card-header">
                    <h2>Data Produk</h2>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Kategori</th>
                            <th>Gambar</th>
                            <th>Harga</th>
                            <th>Deskripsi</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $query_produk = "SELECT * FROM produk";
                        $result_produk = mysqli_query($conn, $query_produk);

                        if (mysqli_num_rows($result_produk) > 0) :
                            while ($row_produk = mysqli_fetch_assoc($result_produk)) :
                        ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $row_produk['nama_produk']; ?></td>
                                    <td><?php echo $row_produk['kategori_produk']; ?></td>
                                    <td><img src="uploads/<?php echo $row_produk['gambar']; ?>" alt="<?php echo $row_produk['nama_produk']; ?>"></td>
                                    <td>Rp <?php echo number_format($row_produk['harga'], 0, ',', '.'); ?></td>
                                    <td><?php echo $row_produk['deskripsi']; ?></td>
                                    <td><?php echo $row_produk['stok']; ?></td>
                                    <td>
                                        <a href="edit_produk.php?id=<?php echo $row_produk['id_produk']; ?>" class="action-link">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="hapus_produk.php?id=<?php echo $row_produk['id_produk']; ?>" onclick="return confirm('Yakin ingin hapus produk ini?');" class="action-link delete">
                                            <i class="fas fa-trash"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                        <?php
                            endwhile;
                        else :
                            echo "<tr><td colspan='7' class='text-center'>Tidak ada data produk.</td></tr>";
                        endif;
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Users Table -->
            <div class="card">
                <div class="card-header">
                    <h2>Data Pengguna</h2>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama Lengkap</th>
                            <th>No Telp</th>
                            <th>Dibuat Pada</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $query_user = "SELECT * FROM user";
                        $result_user = mysqli_query($conn, $query_user);

                        if (mysqli_num_rows($result_user) > 0) :
                            while ($row_user = mysqli_fetch_assoc($result_user)) :
                        ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $row_user['username']; ?></td>
                                    <td><?php echo $row_user['nama_lengkap']; ?></td>
                                    <td><?php echo $row_user['no_telepon']; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row_user['created_at'])); ?></td>
                                </tr>
                        <?php
                            endwhile;
                        else :
                            echo "<tr><td colspan='5' class='text-center'>Tidak ada data pengguna.</td></tr>";
                        endif;
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Orders Table -->
            <div class="card">
                <div class="card-header">
                    <h2>Data Pesanan</h2>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID Pesanan</th>
                            <th>Pelanggan</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query_pesanan = "SELECT pesanan.*, user.username 
                                      FROM pesanan 
                                      JOIN user ON pesanan.id_user = user.id_user
                                      ORDER BY pesanan.created_at DESC";
                        $result_pesanan = mysqli_query($conn, $query_pesanan);

                        if (mysqli_num_rows($result_pesanan) > 0) :
                            while ($row = mysqli_fetch_assoc($result_pesanan)) :
                        ?>
                                <tr>
                                    <td><?= $row['id_pesanan'] ?></td>
                                    <td><?= $row['username'] ?></td>
                                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                                    <td>
                                        <?php 
                                        $status_class = '';
                                        switch($row['status']) {
                                            case 'pending': $status_class = 'badge-pending'; break;
                                            case 'diproses': $status_class = 'badge-diproses'; break;
                                            case 'dikirim': $status_class = 'badge-dikirim'; break;
                                            case 'selesai': $status_class = 'badge-selesai'; break;
                                        }
                                        ?>
                                        <form action="update_status.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="id_pesanan" value="<?= $row['id_pesanan'] ?>">
                                            <select name="status" onchange="this.form.submit()" class="status-select">
                                                <option value="pending" <?= ($row['status'] == 'pending') ? 'selected' : '' ?>>Pending</option>
                                                <option value="diproses" <?= ($row['status'] == 'diproses') ? 'selected' : '' ?>>Diproses</option>
                                                <option value="dikirim" <?= ($row['status'] == 'dikirim') ? 'selected' : '' ?>>Dikirim</option>
                                                <option value="selesai" <?= ($row['status'] == 'selesai') ? 'selected' : '' ?>>Selesai</option>
                                            </select>
                                        </form>
                                    </td>
                                    <td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>
                                    <td>
                                        <a href="detail_pesanan.php?id=<?= $row['id_pesanan'] ?>" class="action-link">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada pesanan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>