<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration | Your App Name</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --text: #333333;
            --text-light: #6c757d;
            --success: #4cc9f0;
            --error: #e63946;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }
        
        .register-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            overflow: hidden;
            position: relative;
        }
        
        .register-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 2rem;
            text-align: center;
            position: relative;
        }
        
        .register-header h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }
        
        .register-header p {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .register-form {
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--text);
        }
        
        .input-field {
            position: relative;
        }
        
        .input-field input,
        .input-field textarea {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.8rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        .input-field textarea {
            min-height: 100px;
            resize: vertical;
            padding-left: 1rem;
        }
        
        .input-field input:focus,
        .input-field textarea:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
        }
        
        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }
        
        .btn-register {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 0.5rem;
        }
        
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .form-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .form-footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .form-footer a:hover {
            color: var(--secondary);
            text-decoration: underline;
        }
        
        .password-strength {
            margin-top: 0.5rem;
            height: 4px;
            background-color: #e9ecef;
            border-radius: 2px;
            overflow: hidden;
            position: relative;
        }
        
        .strength-meter {
            height: 100%;
            width: 0;
            background-color: var(--error);
            transition: width 0.3s ease, background-color 0.3s ease;
        }
        
        .password-requirements {
            margin-top: 0.5rem;
            font-size: 0.8rem;
            color: var(--text-light);
        }
        
        .requirement {
            display: flex;
            align-items: center;
            margin-bottom: 0.3rem;
        }
        
        .requirement i {
            margin-right: 0.5rem;
            font-size: 0.7rem;
        }
        
        .requirement.valid {
            color: var(--success);
        }
        
        .requirement.valid i {
            color: var(--success);
        }
        
        /* Responsive adjustments */
        @media (max-width: 480px) {
            .register-container {
                border-radius: 10px;
            }
            
            .register-header {
                padding: 1.5rem;
            }
            
            .register-form {
                padding: 1.5rem;
            }
            
            .input-field input,
            .input-field textarea {
                padding-left: 2.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h2>Create Your Account</h2>
            <p>Join our community today</p>
        </div>
        
        <form class="register-form" action="proses_register_user.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-field">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="username" name="username" placeholder="Choose a username" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-field">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="password" name="password" placeholder="Create a password" required>
                </div>
                <div class="password-strength">
                    <div class="strength-meter" id="strengthMeter"></div>
                </div>
                <div class="password-requirements">
                    <div class="requirement" id="lengthReq">
                        <i class="fas fa-circle"></i>
                        <span>At least 8 characters</span>
                    </div>
                    <div class="requirement" id="numberReq">
                        <i class="fas fa-circle"></i>
                        <span>Contains a number</span>
                    </div>
                    <div class="requirement" id="specialReq">
                        <i class="fas fa-circle"></i>
                        <span>Contains a special character</span>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="nama_lengkap">Full Name</label>
                <div class="input-field">
                    <i class="fas fa-id-card input-icon"></i>
                    <input type="text" id="nama_lengkap" name="nama_lengkap" placeholder="Your full name" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="no_telepon">Phone Number</label>
                <div class="input-field">
                    <i class="fas fa-phone input-icon"></i>
                    <input type="tel" id="no_telepon" name="no_telepon" placeholder="Your phone number" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="alamat">Address</label>
                <div class="input-field">
                    <textarea id="alamat" name="alamat" placeholder="Your full address" required></textarea>
                </div>
            </div>
            
            <button type="submit" class="btn-register">Create Account</button>
            
            <div class="form-footer">
                Already have an account? <a href="login_user.php">Login Here</a> || <a href="index.php">Back Home</a>
            </div>
        </form>
    </div>

    <script>
        // Password strength indicator
        const passwordInput = document.getElementById('password');
        const strengthMeter = document.getElementById('strengthMeter');
        const lengthReq = document.getElementById('lengthReq');
        const numberReq = document.getElementById('numberReq');
        const specialReq = document.getElementById('specialReq');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            // Check length
            if (password.length >= 8) {
                strength += 1;
                lengthReq.classList.add('valid');
            } else {
                lengthReq.classList.remove('valid');
            }
            
            // Check for numbers
            if (/\d/.test(password)) {
                strength += 1;
                numberReq.classList.add('valid');
            } else {
                numberReq.classList.remove('valid');
            }
            
            // Check for special characters
            if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
                strength += 1;
                specialReq.classList.add('valid');
            } else {
                specialReq.classList.remove('valid');
            }
            
            // Update strength meter
            const width = (strength / 3) * 100;
            strengthMeter.style.width = width + '%';
            
            // Update color based on strength
            // if (strength === 0) {
            //     strengthMeter.style.backgroundColor = var(--error);
            // } else if (strength === 1) {
            //     strengthMeter.style.backgroundColor = '#ff9f1c';
            // } else if (strength === 2) {
            //     strengthMeter.style.backgroundColor = '#2ec4b6';
            // } else {
            //     strengthMeter.style.backgroundColor = var(--success);
            // }
        });
    </script>
</body>
</html>